
# Frontend - SuperCarros Republishing Panel

## Requisitos

- Node.js 18+
- npm o pnpm

## Instalación

```bash
cd frontend
npm install
npm run dev
```

Por defecto, Vite corre en `http://localhost:5173` y el backend en `http://localhost:8000`.  
Puedes configurar un proxy o cambiar las URLs en las llamadas de `axios` si lo necesitas.
